/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analizadorlexico_1cod;

/**
 *
 * @author Itzel cg
 */
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.beans.*;

public class NumeradorLineas extends JPanel {
    private final JTextArea textArea;

    public NumeradorLineas(JTextArea textArea) {
        this.textArea = textArea;
        setFont(textArea.getFont());
        setBackground(new Color(235, 152, 78));
       // setOpaque(true); // Asegura que el color de fondo se pinte correctamente
        setPreferredSize(new Dimension(40, Integer.MAX_VALUE));
        textArea.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { repaint(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { repaint(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) {}
        });
        textArea.addPropertyChangeListener("font", new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
                setFont(textArea.getFont());
                repaint();
            }
        });
    }

    @Override
protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    FontMetrics fm = g.getFontMetrics(getFont());
    int lineHeight = fm.getHeight();

    int lines = textArea.getLineCount();
    int y = lineHeight;

    for (int i = 0; i < lines; i++) {
        g.drawString(String.valueOf(i + 1), 5, y - 4); // Ajuste visual
        y += lineHeight;
    }

    // Asegura que el componente sea lo suficientemente alto para mostrar todo
    setPreferredSize(new Dimension(40, lines * lineHeight));
    revalidate();
}

}

