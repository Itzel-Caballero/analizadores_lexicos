/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analizadorlexico_1cod;

/**
 *
 * @author Itzel cg
 */

import java.util.*;
import java.util.regex.*;

public class Lexer {
    private static final Pattern TOKEN_PATTERNS;
    private static final Map<String, Tokens> KEYWORDS = new HashMap<>();

    static {
        // Definimos palabras clave
        KEYWORDS.put("Robot", Tokens.Robot);
        KEYWORDS.put("iniciar", Tokens.Accion);
        KEYWORDS.put("finalizar", Tokens.Accion);
        KEYWORDS.put("repetir", Tokens.Metodo);
        KEYWORDS.put("abrirGarra", Tokens.Accion);
        KEYWORDS.put("cerrarGarra", Tokens.Accion);
        KEYWORDS.put("mover", Tokens.Accion);
        KEYWORDS.put("detener", Tokens.Accion);
        KEYWORDS.put("base", Tokens.Metodo);
        KEYWORDS.put("garra", Tokens.Metodo);
        KEYWORDS.put("cuerpo", Tokens.Metodo);
        KEYWORDS.put("velocidad", Tokens.Metodo);

        // Regex combinada para todos los tokens
        String regex =
              "(?<COMMENT>//.*)|"
            + "(?<SPACE>[ \\t\\r\\n]+)|"
            + "(?<IDENTIFIER>r[0-9]+)|"
            + "(?<NUMBER>\\d+)|"
            + "(?<OPERATOR>=)|"
            + "(?<SYMBOL>[().])|"
            + "(?<WORD>[a-zA-Z_][a-zA-Z0-9_]*)|"
            + "(?<UNKNOWN>.)";

        TOKEN_PATTERNS = Pattern.compile(regex);
    }

    public static class Token {
        public Tokens type;
        public String lexeme;

        public Token(Tokens type, String lexeme) {
            this.type = type;
            this.lexeme = lexeme;
        }

        public String toString() {
            return String.format("<%s, \"%s\">", type, lexeme);
        }
    }

    public static List<Token> tokenize(String input) {
        List<Token> tokens = new ArrayList<>();
        Matcher matcher = TOKEN_PATTERNS.matcher(input);

        while (matcher.find()) {
            if (matcher.group("COMMENT") != null) {
                continue; // Ignorar comentarios
            }
            if (matcher.group("SPACE") != null) {
                continue; // Ignorar espacios
            }
            if (matcher.group("IDENTIFIER") != null) {
                tokens.add(new Token(Tokens.Identificador, matcher.group()));
                continue;
            }
            if (matcher.group("NUMBER") != null) {
                tokens.add(new Token(Tokens.Numero, matcher.group()));
                continue;
            }
            if (matcher.group("OPERATOR") != null) {
                tokens.add(new Token(Tokens.Operador, matcher.group()));
                continue;
            }
            if (matcher.group("SYMBOL") != null) {
                tokens.add(new Token(Tokens.Simbolo, matcher.group()));
                continue;
            }
            if (matcher.group("WORD") != null) {
                String word = matcher.group();
                Tokens type = KEYWORDS.getOrDefault(word, Tokens.ERROR);
                tokens.add(new Token(type, word));
                continue;
            }
            if (matcher.group("UNKNOWN") != null) {
                tokens.add(new Token(Tokens.Desconocido, matcher.group()));
            }
        }

        return tokens;
    }

    public static void main(String[] args) {
        String code = """
        Robot r1
        r1.iniciar
        r1.base = 90
        r1.cuerpo=45 
        r1.garra=90
        r1.velocidad = 100
        r1.repetir(3)
        r1.abrirGarra()
        r1.cerrarGarra()
        r1.finalizar
        analizar
        #      
        // Esto es un comentario
        """;

        List<Token> tokens = tokenize(code);
        for (Token token : tokens) {
            System.out.println(token);
        }
    }
}

