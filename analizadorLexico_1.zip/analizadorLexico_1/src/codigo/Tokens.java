/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package codigo;

/**
 *
 * @author Itzel cg
 */
public enum Tokens {
    ERROR,
    Desconocido,
    // Palabras reservadas
    Robot,
    Iniciar,
    Finalizar,
    Repetir,

    // Identificadores y literales
    Identificador,
    Numero,

    // Métodos
    Metodo,

    // Acciones específicas
    Accion,
    AbrirGarra,
    CerrarGarra,

   
    Simbolo,
    Operador
}
